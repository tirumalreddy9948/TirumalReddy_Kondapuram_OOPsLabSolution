package com.greatlearning.lab1;

import java.util.Random;

public class CredentialService {
	
	public char[] generatePassword() {
		
		String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lower = "abcdefghijklmnopqrstuvwxyz";
		String num = "0123456789";
		String specialchar = "!@#$%&";
		
		char[] password = new char[8];
		Random rand = new Random();
		
		password[0] = num.charAt(rand.nextInt(num.length()));
		password[1] = num.charAt(rand.nextInt(num.length()));
		password[2] = num.charAt(rand.nextInt(num.length()));
		password[3] = upper.charAt(rand.nextInt(upper.length()));
		password[4] = specialchar.charAt(rand.nextInt(specialchar.length()));
		password[5] = lower.charAt(rand.nextInt(specialchar.length()));
		password[6] = upper.charAt(rand.nextInt(upper.length()));
		password[7] = upper.charAt(rand.nextInt(upper.length()));
				
		return password;
	}
	
	public  String generateEmailAddress(String firstName, String lastName, String deptarmentName) {
		String emailAddress = firstName+lastName+"@"+deptarmentName+".xyz.com";
		
		return emailAddress;
	}
	
	public void showCredentials(String firstname, String email,char[] password) {
		
	System.out.println("Dear "+firstname+" your generated credentials are as follows");
	System.out.println("Email ===> "+email);
	System.out.print("Password ===> ");
	System.out.print(generatePassword());
//	generatePassword();
		
		
	}

}
