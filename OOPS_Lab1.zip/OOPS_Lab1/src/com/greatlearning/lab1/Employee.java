package com.greatlearning.lab1;

public class Employee {
private String firstName, lastName;

String departmentName;
	
	Employee(String firstName, String lastName){
		this.firstName = firstName;
		this.lastName = lastName;
		
	}
	
	/*public void setfirsName(String fName) {
		this.firstName = fName;
		
	} */
	
	public void setlastName(String lName) {
		this.lastName = lName;
		
	}
	
	public String getfirsName() {
		return firstName;
		
	}
	
	public String getlastName() {
		return lastName;
		
	}
	public void getDepartment(int deptnum) {
		
		switch(deptnum) {
		
		case 1 :
			this.departmentName = "Technical";
			break;
		case 2 :
			this.departmentName = "Admin";
			break;
		case 3 :
			this.departmentName = "HumanResource";
			break;
		case 4 :
			this.departmentName = "Legal";
			break;
		default:
			System.out.println("Invalid department number");
			
		} 
		
	}

}
