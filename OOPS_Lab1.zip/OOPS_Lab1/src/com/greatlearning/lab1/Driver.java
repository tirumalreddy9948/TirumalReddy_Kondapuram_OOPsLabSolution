package com.greatlearning.lab1;

import java.util.Scanner;

public class Driver {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
String[] departmentName = {"Technical","Admin","HumanResource","Legal"};
		
		Employee emp = new Employee("Raja","Ramaraju");
		
		String fistName = emp.getfirsName();
		String lastName = emp.getlastName();

		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Please enter the deparmtment from the following : ");
		
		for(int i=0; i<departmentName.length; i++) {
			System.out.println((i+1)+"."+" "+departmentName[i]);
			
		}
		System.out.println();
		 
		int deptId = sc.nextInt();
		
		
		
	if(deptId>departmentName.length) {
			System.out.println("Enter a valid department number from above list");
		}
		else {
		emp.getDepartment(deptId);
		CredentialService service = new CredentialService();
		
		String email = 	service.generateEmailAddress(fistName, lastName, emp.departmentName);
		char[] password = service.generatePassword();
		 service.showCredentials(fistName,email, password);
	
			}

		
	 sc.close();
	}
	
	
}
